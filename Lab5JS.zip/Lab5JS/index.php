<?php
if(!empty($_GET['message'])){
	echo'
<script>
	
	alert("Data Inserted");
</script>
	';
}
?>
<html>
<head>
	<title>
		ANimal Info
	</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<style type="text/css">
		body{
			background-color: #57dc26;
		}
	</style>
</head>
<body>

<div class="container">
	<div class="row">
		<a href="showData.php">view data</a>
		<form action="comman/saveInfo.php" method="POST">
			<div class="form-group">
			<label for="weight">Weight:</label>		
			<input type="text" id="weight" class="form-control" name="weight">
			
	</div>
	<!-- One input ends here !-->

	<div class="form-group">
			<label for="temprature">Temperature:</label>		
			<input type="text" id="temprature" class="form-control" name="temprature">
			
	</div>
	<!-- One input ends here !-->

	<div class="form-group">
			<label for="humidity">Humidity:</label>		
			<input type="text" id="humidity" class="form-control" name="humidity">
			
	</div>
	<!-- One input ends here !-->


<div class="form-group">
			<label for="scientificname">Scientific Name:</label>		
			<input type="text" id="scientificname" class="form-control" name="scientificname">
			
	</div>
	<!-- One input ends here !-->

<div class="form-group">
			<label for="commanname">Common Name:</label>		
			<input type="text" id="commanname" class="form-control" name="commanname">
			
	</div>
	<!-- One input ends here !-->

<div class="form-group">
			<label for="Species">Species:</label>		
			<input type="text" id="Species" class="form-control" name="Species">
			
	</div>
	<!-- One input ends here !-->

<div class="form-group">
			<label for="gender">Gender:</label>		
			<input type="text" id="gender" class="form-control" name="gender">
			
	</div>
	<!-- One input ends here !-->

<div class="form-group">
			<label for="length">Length:</label>		
			<input type="text" id="length" class="form-control" name="length">
			
	</div>
	<!-- One input ends here !-->

<div class="form-group">
			<label for="genus">Genus:</label>		
			<input type="text" id="genus" class="form-control" name="genus">
			
	</div>
	<!-- One input ends here !-->

<div class="form-group">
	<button type="submit" class="text-success"> Save Info</button>
			
	</div>
	<!-- One input ends here !-->



		</form>
	</div>
</div>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>