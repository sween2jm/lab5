<?php


$connection = mysqli_connect('localhost','root','','AnimalInfo');
if($connection){
//we will check if database exists or not
$databaseQuery = 'CREATE DATABASE IF NOT EXISTS AnimalInfo';
$dbCreate = mysqli_query($connection,$databaseQuery);
//here we will get true false result if db creates it will give true
	
}