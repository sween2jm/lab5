<?php
include 'connection.php';
if (!empty($_POST)) {

	// echo "<pre>".print_r($_POST)."</pre>";
	// die;
	//here you can see whatever data is coming

	$createTableQuery = "CREATE TABLE IF NOT EXISTS AnimalInfo (
		RecordID INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		weight VARCHAR(30) NOT NULL,
		temperature VARCHAR(30) NOT NULL,
		humidity VARCHAR(50),
		scientificName VARCHAR(50) NOT NULL,
		commonName VARCHAR(30) NOT NULL,
		species VARCHAR(30) NOT NULL,
		gender VARCHAR(30) NOT NULL,
		length VARCHAR(30) NOT NULL,
		genus VARCHAR(30) NOT NULL
		)";
		// it will check weither table exists or not if not exists it will create table for us
		$createTable = mysqli_query($connection,$createTableQuery);
		if ($createTable) {
			$insertQuery = "
			INSERT INTO AnimalInfo (weight,temperature,humidity,scientificName,commonName,species,gender,length,genus) VALUES('".$_POST['weight']."','".$_POST['temprature']."','".$_POST['humidity']."','".$_POST['scientificname']."','".$_POST['commanname']."',
			'".$_POST['Species']."','".$_POST['gender']."','".$_POST['length']."','".$_POST['genus']."')";
			//here it will genrate query for insert
			// echo $insertQuery;
			// die;
			$insert = mysqli_query($connection,$insertQuery);
			//it will insert 
			if ($insert) {
				//if success this will redirect to index with following msg
				header("location:../index.php?message=success");
			}else{
				//in case of failure it will redirect with following message
				header("location:../index.php?message=failed");
			}


		}
}

?>